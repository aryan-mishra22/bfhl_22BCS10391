import React, { useState, useEffect } from 'react';
import './App.css';
import Select from 'react-select';

function App() {
  const [inputJson, setInputJson] = useState('');
  const [apiResponse, setApiResponse] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [selectedFilters, setSelectedFilters] = useState([]);
  const [filteredResponse, setFilteredResponse] = useState(null);

  // Filter options for multi-select dropdown
  const filterOptions = [
    { value: 'alphabets', label: 'Alphabets' },
    { value: 'numbers', label: 'Numbers' },
    { value: 'highest_alphabet', label: 'Highest alphabet' }
  ];

  // Set document title to your roll number
  useEffect(() => {
    document.title = 'YOUR_ROLL_NUMBER'; // Replace with your actual roll number
  }, []);

  // Handle input change
  const handleInputChange = (e) => {
    setInputJson(e.target.value);
    setError('');
  };

  // Handle filter selection
  const handleFilterChange = (selectedOptions) => {
    setSelectedFilters(selectedOptions || []);
  };

  // Update filtered response when selections or API response changes
  useEffect(() => {
    if (!apiResponse) return;

    // Create a filtered response object based on selected filters
    const filtered = {
      user_id: apiResponse.user_id,
      email: apiResponse.email,
      roll_number: apiResponse.roll_number,
    };

    // Add selected filter data to filtered response
    selectedFilters.forEach(filter => {
      filtered[filter.value] = apiResponse[filter.value];
    });

    setFilteredResponse(filtered);
  }, [selectedFilters, apiResponse]);

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setApiResponse(null);
    setFilteredResponse(null);

    // Validate JSON format
    try {
      const parsedJson = JSON.parse(inputJson);
      
      if (!parsedJson.data || !Array.isArray(parsedJson.data)) {
        setError('Invalid JSON format. Expected a JSON object with a "data" array.');
        return;
      }

      setLoading(true);

      // Replace with your actual API endpoint
      const apiUrl = 'http:/localhost://3000/bfhl';
      
      // Call the API
      try {
        const response = await fetch(apiUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: inputJson,
        });

        const data = await response.json();
        setApiResponse(data);
        
        // Reset selected filters
        setSelectedFilters([]);
      } catch (fetchError) {
        setError('Failed to connect to the API. Please check your connection and try again.');
      } finally {
        setLoading(false);
      }
    } catch (jsonError) {
      setError('Invalid JSON format. Please check your input.');
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>BFHL Developer Challenge</h1>
      </header>
      <main className="App-main">
        <form onSubmit={handleSubmit} className="form-container">
          <div className="form-group">
            <label htmlFor="jsonInput">Enter JSON Input:</label>
            <textarea
              id="jsonInput"
              value={inputJson}
              onChange={handleInputChange}
              placeholder='e.g. { "data": ["A", "1", "B", "2", "C"] }'
              rows={5}
              className="json-input"
            />
          </div>
          
          {error && <div className="error-message">{error}</div>}
          
          <button type="submit" className="submit-button" disabled={loading}>
            {loading ? 'Processing...' : 'Submit'}
          </button>
        </form>
        
        {apiResponse && apiResponse.is_success && (
          <div className="results-container">
            <h2>API Response</h2>
            
            <div className="filter-container">
              <label htmlFor="responseFilter">Select data to display:</label>
              <Select
                id="responseFilter"
                isMulti
                options={filterOptions}
                className="multi-select"
                placeholder="Select filters..."
                value={selectedFilters}
                onChange={handleFilterChange}
              />
            </div>
            
            {filteredResponse && Object.keys(filteredResponse).length > 3 && (
              <div className="json-display">
                <h3>Filtered Response:</h3>
                <pre>{JSON.stringify(filteredResponse, null, 2)}</pre>
              </div>
            )}
            
            {(!filteredResponse || Object.keys(filteredResponse).length <= 3) && selectedFilters.length > 0 && (
              <div className="empty-message">
                Please select at least one filter option to view the response data.
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}

export default App;